﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VMMV.Model;
using VMMV.ViewModel;

namespace VMMV.View
{
    /// <summary>
    /// Lógica de interacción para Window1.xaml
    /// </summary>
    public partial class MainPageArticulos : Window
    {
        public MainPageArticulos()
        {
            InitializeComponent();
        }

        private void Button_Click_Dependientes(object sender, RoutedEventArgs e)
        {
            MainPageDependientes dependientes = new MainPageDependientes();
            dependientes.Show();
            DependientesViewModel VM = new DependientesViewModel();
            dependientes.DataContext = VM;
            this.Close();

        }

        private void Button_Click_Ventas(object sender, RoutedEventArgs e)
        {
            MainPageVentas ventas = new MainPageVentas();
            ventas.Show();
            VentasViewModel V = new VentasViewModel();
            ventas.DataContext = V;
            this.Close();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Borrar(object sender, RoutedEventArgs e)
        {
            if (ArtGrid.SelectedItem != null)
            {
                this.DataContext = ArtGrid.SelectedItem;

                Articulos articulos = new Dependiente();

                DependientesViewModel DependientesViewModel = new DependientesViewModel();

                DependientesViewModel.Dependientes.Remove(dependiente);
            }
            else
            {
                MessageBox.Show("Elige el articulo a borrar");
            }
        }
    }

}
