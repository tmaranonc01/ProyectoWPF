﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VMMV.Model;
using VMMV.View;
using VMMV.ViewModel;

namespace VMMV.View
{
    /// <summary>
    /// Lógica de interacción para MainPage.xaml
    /// </summary>
    public partial class MainPageDependientes : Window
    {
        public MainPageDependientes()
        {
            InitializeComponent();
            
        }

        private void Button_Click_Articulos(object sender, RoutedEventArgs e)
        {
            MainPageArticulos articulos = new MainPageArticulos();
            articulos.Show();
            ArticlosViewModel VM = new ArticlosViewModel();
            articulos.DataContext = VM;
            this.Close();
        }

        private void Button_Click_Ventas(object sender, RoutedEventArgs e)
        {
            MainPageVentas ventas = new MainPageVentas();
            ventas.Show();
            VentasViewModel VM = new VentasViewModel();
            ventas.DataContext = VM;
            this.Close();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }
        private void Borrar(object sender, RoutedEventArgs e)
        {
            if (DependienteGrid.SelectedItem != null)
            {
                this.DataContext = DependienteGrid.SelectedItem;

                Dependiente dependiente= new Dependiente();

                DependientesViewModel DependientesViewModel = new DependientesViewModel();

                DependientesViewModel.Dependientes.Remove(dependiente);
            }
            else
            {
                MessageBox.Show("Elige el articulo a borrar");
            }
        }
    }
}
